# ভূমি সেবা বাংলাদেশ — Android Studio project

## তৈরি করা ফিচার
- বাংলা হোম স্ক্রিন ও সার্ভিস সার্চ
- আপনার দেওয়া ৯টি সাইটের জন্য আলাদা বাটন
- প্রতিটি সাইট অ্যাপের ভেতরের Android WebView-তে খোলে
- ব্যাক ও হোম নেভিগেশন
- HTTPS-only content; SSL certificate error হলে পেজ বন্ধ থাকে

## APK বানানোর নিয়ম
1. কম্পিউটারে Android Studio (সাম্প্রতিক stable version) ইনস্টল করুন।
2. Android Studio থেকে **Open** নির্বাচন করে এই প্রজেক্ট ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** চাপুন।
5. সফল হলে Android Studio-র Build notification থেকে **locate** চাপুন। APK থাকবে `app/build/outputs/apk/debug/app-debug.apk`-এ।

## গুরুত্বপূর্ণ
- এটি Android Studio-তে build করার source project; এই ZIP নিজে APK নয়।
- ওয়েবসাইটগুলোর নিজস্ব লগইন, সার্ভার, অনুমতি বা মোবাইল WebView compatibility-এর ওপর কিছু পেজের কাজ নির্ভর করবে।
- কোনো সাইটে সমস্যা হলে Chrome-এ একই URL খুলে যাচাই করুন।
- সাইটগুলোর মালিকানা/সরকারি অনুমোদন এই অ্যাপ যাচাই করে না; ব্যবহার করার আগে সাইটের সত্যতা যাচাই করুন।
