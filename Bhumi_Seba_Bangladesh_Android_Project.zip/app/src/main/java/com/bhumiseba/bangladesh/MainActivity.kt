package com.bhumiseba.bangladesh

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    private data class Service(val title: String, val url: String, val subtitle: String)
    private val services = listOf(
        Service("আমার ভূমি", "https://www.amarvumi.com/", "ভূমি সংক্রান্ত সেবা"),
        Service("সার্ভে খতিয়ান", "https://eporcha.top/services/survey-khatiyan", "সার্ভে ও খতিয়ান"),
        Service("ই-পর্চা", "https://www.eporcha.tech/", "খতিয়ান সেবা"),
        Service("মৌজা ম্যাপ", "https://e-porcha.com/mouza-map", "মৌজা ম্যাপ দেখুন"),
        Service("NDS ডিজিটাল সার্ভে", "https://www.ndsdigitalsurvey.com/mouza-map/", "ডিজিটাল সার্ভে"),
        Service("নাগরিক সেবা হাব", "https://nagoriksebahub.com/dashboard", "নাগরিক সেবা"),
        Service("ভূমি সেবা", "https://app.bhumisheba.com/", "ভূমি সেবা অ্যাপ"),
        Service("সরকারি খতিয়ান অনুসন্ধান", "https://settlement.gov.bd/Khatian/Search", "সরকারি খতিয়ান অনুসন্ধান"),
        Service("FlexiTaka", "https://flexitaka.com/app", "অনলাইন সেবা")
    )

    private lateinit var root: LinearLayout
    private lateinit var webView: WebView
    private lateinit var webTitle: TextView
    private lateinit var homeButton: Button
    private var showingWeb = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun showHome() {
        showingWeb = false
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF4F8F5.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            setBackgroundColor(0xFF145C38.toInt())
        }
        header.addView(text("🇧🇩", 32f, 0xFFFFFFFF.toInt()))
        header.addView(text("ভূমি সেবা বাংলাদেশ", 24f, 0xFFFFFFFF.toInt(), true))
        header.addView(text("আপনার জমি, আপনার সেবা", 14f, 0xFFE1F2E7.toInt()))
        root.addView(header)

        val search = EditText(this).apply {
            hint = "সেবা খুঁজুন..."
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val searchWrap = LinearLayout(this).apply {
            setPadding(dp(14), dp(12), dp(14), dp(4))
            addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        }
        root.addView(searchWrap)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(18))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun populate(filter: String) {
            list.removeAllViews()
            services.filter { it.title.contains(filter, true) || it.subtitle.contains(filter, true) }
                .forEach { service ->
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(16), dp(14), dp(16), dp(14))
                        setBackgroundColor(0xFFFFFFFF.toInt())
                        elevation = dp(2).toFloat()
                    }
                    card.addView(text(service.title, 17f, 0xFF173D2A.toInt(), true))
                    val sub = text(service.subtitle, 13f, 0xFF65756B.toInt())
                    sub.setPadding(0, dp(4), 0, dp(8))
                    card.addView(sub)
                    val open = Button(this).apply {
                        text = "সেবা খুলুন"
                        isAllCaps = false
                        setTextColor(0xFFFFFFFF.toInt())
                        setBackgroundColor(0xFF167A45.toInt())
                        setOnClickListener { openService(service) }
                    }
                    card.addView(open, LinearLayout.LayoutParams(-1, dp(44)))
                    val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.bottomMargin = dp(12)
                    list.addView(card, lp)
                }
        }
        populate("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openService(service: Service) {
        showingWeb = true
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setBackgroundColor(0xFF145C38.toInt())
        }
        val back = Button(this).apply {
            text = "‹"
            textSize = 26f
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF145C38.toInt())
            setOnClickListener { if (webView.canGoBack()) webView.goBack() else showHome() }
        }
        homeButton = Button(this).apply {
            text = "হোম"
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF145C38.toInt())
            setOnClickListener { showHome() }
        }
        webTitle = text(service.title, 16f, 0xFFFFFFFF.toInt(), true)
        bar.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        bar.addView(webTitle, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(homeButton)
        page.addView(bar)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        webView.settings.safeBrowsingEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return uri.scheme != "https" && uri.scheme != "http"
            }
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                handler?.cancel()
            }
        }
        webView.webChromeClient = WebChromeClient()
        page.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        webView.loadUrl(service.url)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingWeb && ::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else if (showingWeb) {
            showHome()
        } else {
            super.onBackPressed()
        }
    }
}
